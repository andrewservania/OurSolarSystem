/**
@page screenshots Screenshots

Here are the mandatory screenshots.

@image html ansi.png
@image html cube.png
@image html font.png
@image html markup.png
@image html atb-agg.png
@image html distance-field-1.png
@image html gamma.png
@image html outline.png
@image html cartoon.png
@image html distance-field-2.png
@image html glyph.png
@image html subpixel.png
@image html console.png
@image html distance-field-3.png
@image html line.png
@image html texture.png

*/
